﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MessageBox = System.Windows.MessageBox;

namespace project_findFIle
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        string path;
        string pathCopy;
        private void bt_selectfile_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog folderBrowser = new FolderBrowserDialog();
            if (folderBrowser.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                path = folderBrowser.SelectedPath;
                this.bt_start.IsEnabled = true;
                this.tb_pathSelectFile.Text = path;
                //
            }
        }
        private void bt_fileSave_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog folderBrowser = new FolderBrowserDialog();
            if (folderBrowser.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                pathCopy = folderBrowser.SelectedPath;
                this.tb_pathSaveFile.Text = pathCopy;

            }
        }
        private async void bt_start_Click(object sender, RoutedEventArgs e)
        {
            string word = tb_word.Text;
            await Task.Run(() => analiz_file(word));
            Process.Start(pathCopy);
        }
        private async void analiz_file(string select_word)
        {
            ConcurrentBag<string> files = new ConcurrentBag<string>();
            foreach (var item in Directory.GetDirectories(path))
            {
                try
                {
                    await Task.Run(() =>
                    {
                        try
                        {
                            foreach (var file in Directory.GetFiles(item, "*.txt", SearchOption.AllDirectories))
                            {
                                files.Add(file);
                            }
                        }
                        catch { }
                    });
                }
                catch { }
            }
            //
            ConcurrentBag<info_file> tempReadyFile = new ConcurrentBag<info_file>();
            Parallel.ForEach(files, (a) =>
            {
                using (StreamReader sr = new StreamReader(a))
                {
                    string line = sr.ReadLine();
                    int counter = 0;
                    if (line != null)
                    {
                        string[] words = line.Split(new char[] { ' ', ',', '.', '!', '?' }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (string word in words)
                        {
                            if (word == select_word)
                            {
                                counter++;
                            }
                        }
                        if (counter != 0)
                        {
                            FileInfo fileInfo = new FileInfo(a);
                            tempReadyFile.Add(new info_file()
                            {
                                name = System.IO.Path.GetFileName(a),
                                path = a,
                                capacity = fileInfo.Length / 1024.0
                            });
                        }
                    }
                }
            });
            int totalFiles = 0; 
            totalFiles = tempReadyFile.Count;
            Dispatcher.Invoke(() =>
            {
                this.pb_info.Maximum = totalFiles;
                this.pb_info.Value = 0;
                this.tb_proggresinfo.Text = $"Max: {totalFiles} , now -> 0";
            });
            //
            await Task.Run(()=>create_file(tempReadyFile, pathCopy,select_word));
            Dispatcher.Invoke(() =>
            {
                MessageBox.Show("Аналіз завершено!");
                this.pb_info.Value = 0;
            });
        }
        private void create_file(ConcurrentBag<info_file> tempReadyFile, string destinationDirectory,string wordToReplace)
        {
            if (!Directory.Exists(destinationDirectory))
            {
                Directory.CreateDirectory(destinationDirectory);
            }
            Parallel.ForEach(tempReadyFile, (a) =>
            {
                try
                {
                    string fileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(a.path);
                    string fileExtension = System.IO.Path.GetExtension(a.path);
                    string newFileName = $"{fileNameWithoutExtension}-(copy){fileExtension}";
                    string destinationPath = System.IO.Path.Combine(destinationDirectory, newFileName);
                    string content = File.ReadAllText(a.path);

                    char[] delimiters = new char[] { ' ', ',', '.', '!', '?', ':', ';', '-', '\n', '\r', '\t' };
                    string[] words = content.Split(delimiters, StringSplitOptions.None);

                    string updatedContent = "";
                    foreach (string word in words)
                    {
                        if (word == wordToReplace)
                        {
                            updatedContent += "*******";
                        }
                        else
                        {
                            updatedContent += word + " ";
                        }
                    }

                    File.WriteAllText(destinationPath, updatedContent.ToString().Trim());
                }
                catch
                { }
                finally
                {
                    Dispatcher.Invoke(() =>
                    {
                        this.pb_info.Value++;
                        this.tb_proggresinfo.Text = $"Max: {tempReadyFile.Count} , now -> {pb_info.Value}";
                    });
                }
                
            });
            string filePath = System.IO.Path.Combine(destinationDirectory, "__ResultFile__Info.txt");

            using (StreamWriter sw = File.CreateText(filePath))
            {
                foreach(var a in tempReadyFile)
                {
                    sw.WriteLine(a.ToString());
                }
            }

        }

        struct info_file
        {
            public string name;
            public string path;
            public double capacity;
            public override string ToString()
            {
                return $"Name:{name}\nPath:{path}\nCapacity:{capacity} kb\n";
            }
        }

        
    }
}
